﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            packageLocation.Text =
                @"H:\class-projects\SSIS\Integration Services Project1\Integration Services Project1\Package.dtsx";
            dataSource.Text =
                @"Data Source=.\SQLEXPRESS2016;Initial Catalog=demo_ssis;Persist Security Info=True;User ID=sa;Password=Password1;";
            flatFileFolder.Text = @"H:\class-projects\SSIS";
        }

        private void importFlatDataToSql()
        {
            string[] files = Directory.GetFiles(flatFileFolder.Text, "*.txt");
            foreach (var file in files)
            {
                ////string strCmdText;
                ////strCmdText = $"/C dtexec /f \"{packageLocation.Text}\" /set \\package.variables[file_path_import];\"{Path.Combine(flatFileFolder.Text, file)}\" /set \\package.variables[datasource_connection_string];\"{dataSource.Text}\"";
                ////System.Diagnostics.Process.Start("CMD.exe", strCmdText);
                //System.Diagnostics.Process process = new System.Diagnostics.Process();
                //System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
                //// startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                //startInfo.FileName = "cmd.exe";
                //startInfo.Arguments = $"/C dtexec /f \"{packageLocation.Text}\" /set \\package.variables[file_path_import];\"{Path.Combine(flatFileFolder.Text, file)}\" /set \\package.variables[datasource_connection_string];\"{dataSource.Text}\"";
                //startInfo.UseShellExecute = false;
                //startInfo.RedirectStandardOutput = true;
                //var result = Process.Start(startInfo);
                //result.WaitForExit();
                var sb = new StringBuilder();

                Process p = new Process();

                // redirect the output
                p.StartInfo.RedirectStandardOutput = true;
                p.StartInfo.RedirectStandardError = true;
                p.StartInfo.FileName = "cmd.exe";
                p.StartInfo.Arguments = $"/C dtexec /f \"{packageLocation.Text}\" /set \\package.variables[file_path_import];\"{Path.Combine(flatFileFolder.Text, file)}\" /set \\package.variables[datasource_connection_string];\"\\\"{dataSource.Text}\\\"\"";

                // hookup the eventhandlers to capture the data that is received
                p.OutputDataReceived += (sender, args) =>
                {
                    sb.AppendLine(args.Data);
                    Debug.WriteLine(args.Data);
                };
                p.ErrorDataReceived += (sender, args) =>
                {
                    sb.AppendLine(args.Data);
                    Debug.WriteLine(args.Data);
                };

                // direct start
                p.StartInfo.UseShellExecute = false;

                p.Start();
                // start our event pumps
                p.BeginOutputReadLine();
                p.BeginErrorReadLine();

                // until we are done
                //process.StartInfo = startInfo;
                //process.Start();
                //process.WaitForExit();

            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            var result = openFileDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                packageLocation.Text = openFileDialog1.FileName;
                openFileDialog1.FileName = string.Empty;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(flatFileFolder.Text) || string.IsNullOrWhiteSpace(packageLocation.Text) ||
                string.IsNullOrWhiteSpace(dataSource.Text))
            {
                MessageBox.Show("Chưa nhập đủ dữ liệu yêu cầu!!!");
                return;
            }

            importFlatDataToSql();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var result = folderBrowserDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                flatFileFolder.Text = folderBrowserDialog1.SelectedPath;
            }
        }
    }
}
